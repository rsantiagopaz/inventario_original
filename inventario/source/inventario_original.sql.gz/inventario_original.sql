-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-01-2019 a las 10:55:42
-- Versión del servidor: 10.1.31-MariaDB
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inventario_original`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bien`
--

CREATE TABLE `bien` (
  `id_bien` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_expediente` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_tipo_bien` int(11) DEFAULT NULL,
  `organismo_area_id` varchar(5) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_serie` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_tipo_alta` int(11) DEFAULT NULL,
  `fecha_alta` date DEFAULT NULL,
  `id_oas_usuario_alta` int(11) DEFAULT NULL,
  `id_tipo_baja` int(11) DEFAULT NULL,
  `fecha_baja` date DEFAULT NULL,
  `id_oas_usuario_baja` int(11) DEFAULT NULL,
  `proveedor` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_remito` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cuit` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observa_alta` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observa_baja` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `codigo_barra` varchar(1000) COLLATE utf8_spanish_ci DEFAULT NULL,
  `codigo_qr` varchar(1000) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE `movimiento` (
  `id_movimiento` int(11) NOT NULL,
  `id_bien` int(11) DEFAULT NULL,
  `tipo_movimiento` enum('A','B','P') COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_movimiento` date DEFAULT NULL,
  `id_organismo_area_servicio_origen` int(11) DEFAULT NULL,
  `id_organismo_area_servicio_destino` int(11) DEFAULT NULL,
  `id_oas_usuario_movimiento` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_alta`
--

CREATE TABLE `tipo_alta` (
  `id_tipo_alta` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_baja`
--

CREATE TABLE `tipo_baja` (
  `id_tipo_baja` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_bien`
--

CREATE TABLE `tipo_bien` (
  `id_tipo_bien` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bien`
--
ALTER TABLE `bien`
  ADD PRIMARY KEY (`id_bien`);

--
-- Indices de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD PRIMARY KEY (`id_movimiento`);

--
-- Indices de la tabla `tipo_alta`
--
ALTER TABLE `tipo_alta`
  ADD PRIMARY KEY (`id_tipo_alta`);

--
-- Indices de la tabla `tipo_baja`
--
ALTER TABLE `tipo_baja`
  ADD PRIMARY KEY (`id_tipo_baja`);

--
-- Indices de la tabla `tipo_bien`
--
ALTER TABLE `tipo_bien`
  ADD PRIMARY KEY (`id_tipo_bien`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bien`
--
ALTER TABLE `bien`
  MODIFY `id_bien` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  MODIFY `id_movimiento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_alta`
--
ALTER TABLE `tipo_alta`
  MODIFY `id_tipo_alta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_baja`
--
ALTER TABLE `tipo_baja`
  MODIFY `id_tipo_baja` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_bien`
--
ALTER TABLE `tipo_bien`
  MODIFY `id_tipo_bien` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
